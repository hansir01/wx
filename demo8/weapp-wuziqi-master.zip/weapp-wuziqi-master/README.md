# 微信小程序－五子棋

### 说明：

实现五子棋功能。

### 数据接口:

使用本地数据

### 目录结构：

- FiveStone — 存放五子棋逻辑文件
- images — 存放项目图片文件
- pages — 存放项目页面文件
- utils — 存放格式化文件

### 开发环境：

微信web开发者工具 v0.11.122100

### 项目截图：

https://www.getweapp.com/project?projectId=58931db652e1e8733dc567f0

### 感谢：

本项目原始版本由zhiselfly提供：https://github.com/zhiselfly/WXApp-FiveStone