<?php
defined('IN_IA') or exit('Access Denied');

define('STORE_UNPAY_STATUS', '1');
define('STORE_SURE_STATUS', '2');
define('STORE_CANCLE_STATUS', '3');
define('STORE_REPAY_STATUS', '4');
define('STORE_UNLIVE_STATUS', '5');
define('STORE_REFUSE_STATUS', '6');
define('STORE_REPAY_SUCCESS_STATUS', '7');
define('STORE_LIVE_STATUS', '8');
define('STORE_OVER_STATUS', '9');
define('STORE_UNSENT_STATUS', '10');
define('STORE_SENT_STATUS', '11');
define('STORE_GETGOODS_STATUS', '12');
define('STORE_CONFIRM_STATUS', '13');