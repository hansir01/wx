<?php
pdo_query("CREATE TABLE IF NOT EXISTS `ims_storex_plugin_foods` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`storeid` int(11) NOT NULL,
`title` varchar(100) NOT NULL,
`price` decimal(10,2) NOT NULL,
`sold_num` int(11) NOT NULL,
`thumbs` text NOT NULL,
`content` text NOT NULL,
`status` tinyint(4) NOT NULL,
`foods_set` varchar(200) NOT NULL,
`weid` int(11) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_foods_order` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`time` int(11) NOT NULL,
`weid` int(11) NOT NULL,
`storeid` int(11) NOT NULL,
`eattime` int(11) NOT NULL,
`place` varchar(48) NOT NULL,
`remark` varchar(255) NOT NULL,
`mngtime` int(11) NOT NULL,
`foods` text NOT NULL,
`status` int(2) NOT NULL,
`sumprice` decimal(10,2) NOT NULL,
`ordersn` varchar(30) NOT NULL,
`openid` varchar(255) NOT NULL,
`mobile` varchar(255) NOT NULL,
`contact_name` varchar(255) NOT NULL,
`paystatus` tinyint(2) NOT NULL,
`paytype` varchar(20) NOT NULL,
`foods_set` varchar(50) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_foods_set` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11) NOT NULL,
`storeid` int(11) NOT NULL,
`place` varchar(500) NOT NULL,
`foods_set` varchar(500) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_room_goods` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11),
`storeid` int(11),
`title` varchar(255),
`price` decimal(10,2),
`status` tinyint(3) unsigned NOT NULL,
PRIMARY KEY (`id`),
KEY `uniacid` (`uniacid`),
KEY `storeid` (`storeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_room_item` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11),
`items` varchar(1000),
`storeid` int(11),
`openid` varchar(255),
`time` int(10) unsigned NOT NULL,
`status` tinyint(3) unsigned NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_tel` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11),
`tel` varchar(100),
`storeid` int(11),
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_wifi` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11),
`wifi` varchar(1000),
`storeid` int(11),
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

");
