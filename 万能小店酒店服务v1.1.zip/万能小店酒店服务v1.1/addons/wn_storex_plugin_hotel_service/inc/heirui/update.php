<?php
pdo_query("CREATE TABLE IF NOT EXISTS `ims_storex_plugin_foods` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`storeid` int(11) NOT NULL,
`title` varchar(100) NOT NULL,
`price` decimal(10,2) NOT NULL,
`sold_num` int(11) NOT NULL,
`thumbs` text NOT NULL,
`content` text NOT NULL,
`status` tinyint(4) NOT NULL,
`foods_set` varchar(200) NOT NULL,
`weid` int(11) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_foods_order` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`time` int(11) NOT NULL,
`weid` int(11) NOT NULL,
`storeid` int(11) NOT NULL,
`eattime` int(11) NOT NULL,
`place` varchar(48) NOT NULL,
`remark` varchar(255) NOT NULL,
`mngtime` int(11) NOT NULL,
`foods` text NOT NULL,
`status` int(2) NOT NULL,
`sumprice` decimal(10,2) NOT NULL,
`ordersn` varchar(30) NOT NULL,
`openid` varchar(255) NOT NULL,
`mobile` varchar(255) NOT NULL,
`contact_name` varchar(255) NOT NULL,
`paystatus` tinyint(2) NOT NULL,
`paytype` varchar(20) NOT NULL,
`foods_set` varchar(50) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_foods_set` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11) NOT NULL,
`storeid` int(11) NOT NULL,
`place` varchar(500) NOT NULL,
`foods_set` varchar(500) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_room_goods` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11),
`storeid` int(11),
`title` varchar(255),
`price` decimal(10,2),
`status` tinyint(3) unsigned NOT NULL,
PRIMARY KEY (`id`),
KEY `uniacid` (`uniacid`),
KEY `storeid` (`storeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_room_item` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11),
`items` varchar(1000),
`storeid` int(11),
`openid` varchar(255),
`time` int(10) unsigned NOT NULL,
`status` tinyint(3) unsigned NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_tel` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11),
`tel` varchar(100),
`storeid` int(11),
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ims_storex_plugin_wifi` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uniacid` int(11),
`wifi` varchar(1000),
`storeid` int(11),
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

");
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'id')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'storeid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `storeid` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'title')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `title` varchar(100) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'price')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `price` decimal(10,2) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'sold_num')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `sold_num` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'thumbs')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `thumbs` text NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'content')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `content` text NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'status')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `status` tinyint(4) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'foods_set')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `foods_set` varchar(200) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods')) {
	if(!pdo_fieldexists('storex_plugin_foods',  'weid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods')." ADD `weid` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'id')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'time')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `time` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'weid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `weid` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'storeid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `storeid` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'eattime')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `eattime` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'place')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `place` varchar(48) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'remark')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `remark` varchar(255) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'mngtime')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `mngtime` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'foods')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `foods` text NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'status')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `status` int(2) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'sumprice')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `sumprice` decimal(10,2) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'ordersn')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `ordersn` varchar(30) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'openid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `openid` varchar(255) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'mobile')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `mobile` varchar(255) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'contact_name')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `contact_name` varchar(255) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'paystatus')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `paystatus` tinyint(2) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'paytype')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `paytype` varchar(20) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_order')) {
	if(!pdo_fieldexists('storex_plugin_foods_order',  'foods_set')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_order')." ADD `foods_set` varchar(50) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_set')) {
	if(!pdo_fieldexists('storex_plugin_foods_set',  'id')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_set')." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_set')) {
	if(!pdo_fieldexists('storex_plugin_foods_set',  'uniacid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_set')." ADD `uniacid` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_set')) {
	if(!pdo_fieldexists('storex_plugin_foods_set',  'storeid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_set')." ADD `storeid` int(11) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_set')) {
	if(!pdo_fieldexists('storex_plugin_foods_set',  'place')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_set')." ADD `place` varchar(500) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_foods_set')) {
	if(!pdo_fieldexists('storex_plugin_foods_set',  'foods_set')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_foods_set')." ADD `foods_set` varchar(500) NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_room_goods')) {
	if(!pdo_fieldexists('storex_plugin_room_goods',  'id')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_goods')." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
	}	
}
if(pdo_tableexists('storex_plugin_room_goods')) {
	if(!pdo_fieldexists('storex_plugin_room_goods',  'uniacid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_goods')." ADD `uniacid` int(11);");
	}	
}
if(pdo_tableexists('storex_plugin_room_goods')) {
	if(!pdo_fieldexists('storex_plugin_room_goods',  'storeid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_goods')." ADD `storeid` int(11);");
	}	
}
if(pdo_tableexists('storex_plugin_room_goods')) {
	if(!pdo_fieldexists('storex_plugin_room_goods',  'title')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_goods')." ADD `title` varchar(255);");
	}	
}
if(pdo_tableexists('storex_plugin_room_goods')) {
	if(!pdo_fieldexists('storex_plugin_room_goods',  'price')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_goods')." ADD `price` decimal(10,2);");
	}	
}
if(pdo_tableexists('storex_plugin_room_goods')) {
	if(!pdo_fieldexists('storex_plugin_room_goods',  'status')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_goods')." ADD `status` tinyint(3) unsigned NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_room_item')) {
	if(!pdo_fieldexists('storex_plugin_room_item',  'id')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_item')." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
	}	
}
if(pdo_tableexists('storex_plugin_room_item')) {
	if(!pdo_fieldexists('storex_plugin_room_item',  'uniacid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_item')." ADD `uniacid` int(11);");
	}	
}
if(pdo_tableexists('storex_plugin_room_item')) {
	if(!pdo_fieldexists('storex_plugin_room_item',  'items')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_item')." ADD `items` varchar(1000);");
	}	
}
if(pdo_tableexists('storex_plugin_room_item')) {
	if(!pdo_fieldexists('storex_plugin_room_item',  'storeid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_item')." ADD `storeid` int(11);");
	}	
}
if(pdo_tableexists('storex_plugin_room_item')) {
	if(!pdo_fieldexists('storex_plugin_room_item',  'openid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_item')." ADD `openid` varchar(255);");
	}	
}
if(pdo_tableexists('storex_plugin_room_item')) {
	if(!pdo_fieldexists('storex_plugin_room_item',  'time')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_item')." ADD `time` int(10) unsigned NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_room_item')) {
	if(!pdo_fieldexists('storex_plugin_room_item',  'status')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_room_item')." ADD `status` tinyint(3) unsigned NOT NULL;");
	}	
}
if(pdo_tableexists('storex_plugin_tel')) {
	if(!pdo_fieldexists('storex_plugin_tel',  'id')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_tel')." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
	}	
}
if(pdo_tableexists('storex_plugin_tel')) {
	if(!pdo_fieldexists('storex_plugin_tel',  'uniacid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_tel')." ADD `uniacid` int(11);");
	}	
}
if(pdo_tableexists('storex_plugin_tel')) {
	if(!pdo_fieldexists('storex_plugin_tel',  'tel')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_tel')." ADD `tel` varchar(100);");
	}	
}
if(pdo_tableexists('storex_plugin_tel')) {
	if(!pdo_fieldexists('storex_plugin_tel',  'storeid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_tel')." ADD `storeid` int(11);");
	}	
}
if(pdo_tableexists('storex_plugin_wifi')) {
	if(!pdo_fieldexists('storex_plugin_wifi',  'id')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_wifi')." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
	}	
}
if(pdo_tableexists('storex_plugin_wifi')) {
	if(!pdo_fieldexists('storex_plugin_wifi',  'uniacid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_wifi')." ADD `uniacid` int(11);");
	}	
}
if(pdo_tableexists('storex_plugin_wifi')) {
	if(!pdo_fieldexists('storex_plugin_wifi',  'wifi')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_wifi')." ADD `wifi` varchar(1000);");
	}	
}
if(pdo_tableexists('storex_plugin_wifi')) {
	if(!pdo_fieldexists('storex_plugin_wifi',  'storeid')) {
		pdo_query("ALTER TABLE ".tablename('storex_plugin_wifi')." ADD `storeid` int(11);");
	}	
}
