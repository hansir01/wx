<?php
pdo_query("DROP TABLE IF EXISTS `ims_storex_plugin_foods`;
DROP TABLE IF EXISTS `ims_storex_plugin_foods_order`;
DROP TABLE IF EXISTS `ims_storex_plugin_foods_set`;
DROP TABLE IF EXISTS `ims_storex_plugin_room_goods`;
DROP TABLE IF EXISTS `ims_storex_plugin_room_item`;
DROP TABLE IF EXISTS `ims_storex_plugin_tel`;
DROP TABLE IF EXISTS `ims_storex_plugin_wifi`;
");
